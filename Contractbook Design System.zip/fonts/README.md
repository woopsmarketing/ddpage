# Fonts

## Primary typeface — ABC Whyte (Dinamo)

Contractbook uses **ABC Whyte** by Dinamo as its primary typeface. ABC Whyte is a commercial typeface and licensed font files are not bundled in this design system.

- Foundry: https://abcdinamo.com/typefaces/whyte
- Designers: Johannes Breyer, Fabian Harb, Erkin Karamemet
- Weights used by the system: **400 (Regular), 700 (Bold)**

## Substitution

While ABC Whyte is unavailable, this design system substitutes **Inter** (loaded from Google Fonts) at the same weights. Inter is a humanist grotesque with broadly similar proportions; the substitution preserves overall layout and hierarchy but loses some of Whyte's idiosyncratic character (the looser apertures, the slightly chunky terminals).

The CSS stack falls through gracefully:

```css
--font-abcwhyte: 'ABC Whyte', 'Inter', ui-sans-serif, system-ui, ...;
```

If you license ABC Whyte, drop the `.woff2` files into this folder and uncomment the `@font-face` block in `fonts.css` (see below) — everything else will pick it up automatically.

## ⚠ Flagged to user

ABC Whyte is a paid licensed typeface and is **not included** in this project. Inter is acting as a stand-in. If you have access to the Contractbook brand fonts, please drop them in `fonts/` and replace the substitution.

## Adding the real font files

If you have licensed ABC Whyte files (`.woff2`), drop them in this directory and add the following to `fonts.css`:

```css
@font-face {
  font-family: 'ABC Whyte';
  src: url('./ABCWhyte-Regular.woff2') format('woff2');
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: 'ABC Whyte';
  src: url('./ABCWhyte-Bold.woff2') format('woff2');
  font-weight: 700;
  font-style: normal;
  font-display: swap;
}
```
