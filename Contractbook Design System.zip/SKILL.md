---
name: contractbook-design
description: Use this skill to generate well-branded interfaces and assets for Contractbook, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## At a glance

- **Brand:** Contractbook — contract management platform
- **Theme:** light
- **Vibe:** playful professionalism, high-contrast clarity, generous whitespace
- **Primary type:** ABC Whyte (substitute: Inter), weights 400 & 700 only
- **Anchor colors:** Energy Gold `#ffba09` (CTA) · Royal Blue `#1009f6` (statement) · Washed Black `#1a1a1a` (text) · Pure White `#ffffff` (canvas)
- **Radii:** 4.375 (inputs) · 24 (cards) · 40 (images) · 999 (buttons/tags)
- **Section gap:** 60px (non-negotiable)
- **No:** emoji, gradients on UI, drop shadows, multiple fonts, arbitrary radii.

## Files in this skill

- `README.md` — full brand guide (content + visual + iconography)
- `colors_and_type.css` — drop-in CSS custom properties
- `fonts/` — `@font-face` stub + notes on the Inter substitution
- `assets/` — logo, brand marks, illustration placeholders
- `preview/` — small specimen cards (color, type, components)
- `ui_kits/marketing/` — marketing-site recreation
- `ui_kits/app/` — in-product app recreation
