# Contractbook Design System

> Playful professionalism, high-contrast clarity.

Contractbook is a contract management platform — a single place for legal, ops, sales and finance teams to draft, negotiate, sign, store and track contracts across the full lifecycle. The product positioning is anti-bloat: one tool instead of a stack of email threads, drawers, e-signature add-ons and spreadsheets. The voice is friendly and direct — "no fluff, just answers" — but the visual system is confident and grown-up, leaning on a pared-back light canvas punctuated by Energy Gold (CTAs) and Royal Blue (statements).

This repo is the foundation: tokens, typography, components, sample screens and a SKILL.md that lets an agent design *as* Contractbook.

---

## Sources

This design system was built from a **brand style reference document** supplied at project kickoff. No codebase, Figma file or screenshot bundle was attached — so the visual recreation in `ui_kits/` is built from the public marketing site (`https://contractbook.com`) and the style reference, NOT from production source.

If/when you have additional context, please attach:
- The Contractbook web/marketing codebase (Webflow export, Next.js repo, etc.)
- A Figma URL for the design system or marketing site
- The app codebase (the in-product contract editor / dashboard)
- Licensed ABC Whyte font files (see `fonts/README.md`)

Once attached, regenerate `ui_kits/` so the recreation matches production pixel-for-pixel.

---

## Index — what's in this project

| File / folder | Purpose |
|---|---|
| `README.md` | This file. Brand context + content + visual foundations + iconography. |
| `SKILL.md` | Agent-invocable skill spec. Read this first if you're an agent. |
| `colors_and_type.css` | All CSS custom properties: colors, type scale, spacing, radii. Import this. |
| `fonts/` | Font stack notes + `@font-face` stub for ABC Whyte. Inter is the live substitute. |
| `assets/` | Logos, illustration placeholders, brand marks. |
| `preview/` | Small specimen cards that render in the Design System tab. |
| `ui_kits/marketing/` | Marketing-site recreation (hero, features, footer, nav). |
| `ui_kits/app/` | In-product app recreation (contract list, editor, signing). |

---

## Content Fundamentals

### Voice

Contractbook copy lives at the intersection of "law firm" and "your friend who's a lawyer." It is **plainspoken, second-person, and lightly opinionated** — never legalese, never wacky. The brand promise is the abolition of contract-headaches; the copy demonstrates that promise by being short, declarative, and slightly cheeky.

**Sentence shape:** short to medium. Lots of em-dashes for breath. Sentence fragments are fine for callouts.

**Person:** "you" (the customer) and "we" / "Contractbook" (the product). Almost never "I." Customer-quotes are kept in first person and labeled.

**Casing:**
- Headlines: **sentence case** ("Everything you need to manage, track, and finalize contracts").
- Buttons: **Title Case** but kept short ("Book a demo", "Try for free", "See it in action").
- Nav and UI labels: sentence case.
- No ALL-CAPS for emphasis. Use weight + color instead.

**Punctuation:**
- Em-dashes ( — ) generously, often two per paragraph, to slow the reader down.
- Oxford commas, always.
- Exclamation points are rare but allowed in marketing voice ("No pressure — just solutions that make sense!").

**Emoji:** No. Contractbook does not use emoji in product or marketing copy. Reach for typography, color blocks or illustration instead.

**Tone words:** confident, plain, breezy-but-professional, dry-but-warm, anti-bureaucratic.

### Examples (lifted from the live marketing site)

- > Everything you need to manage, track, and finalize contracts — all in one clear, actionable space.
- > No more clunky tools, overcomplicated steps, or hours wasted searching for answers.
- > No pressure — just solutions that make sense.
- > Half the work in fixing a problem is admitting you have one.
- > Your goals, your demo: tell us what you need, and we'll tailor a 1:1 walkthrough just for you.

Notice the pattern: a punchy promise → an em-dash → a clarifying clause. Or: a small declarative truth → a callback to the customer's pain.

### Avoid

- "Revolutionary", "10x", "game-changing", "best-in-class" — marketing-deck filler.
- Mid-sentence ALL CAPS.
- Stacked metaphors. Pick one and commit.
- Emoji.
- Hedge words ("might", "could potentially", "in some cases") — Contractbook is confident.

---

## Visual Foundations

### Mood in one sentence
A clean white room with one bright yellow chair and one royal-blue door. You know exactly where to sit and where to go.

### Color
The system is **light-first**. Pure White (`#ffffff`) is the dominant surface; Pearl (`#f7f7f3`) handles alternating section breaks; Beige (`#f0f0ec`) is the "touchable" neutral — inputs, secondary cards, tactile groupings.

Color is used as **structural blocking**, not decoration. A Royal Blue card or an Energy Gold card is a *region of meaning*, not a flourish. Avoid scattering accent colors as small ornamental dots — commit fully or not at all.

- **Energy Gold (`#ffba09`)** — primary CTA, single most important action on the screen. Pill button. Black text on top.
- **Royal Blue (`#1009f6`)** — statement headlines, key feature cards, link emphasis. White text on top.
- **Sky Blue, Thistle Bloom, Deep Moss** — illustration fills and decorative accents, NOT primary UI surfaces.

No gradients on UI elements. Solid fills only. The only acceptable gradient is a *protection gradient* over imagery for legibility (rare).

### Type
**ABC Whyte** (substituted with **Inter** here — see `fonts/README.md`). Only two weights live in production: 400 and 700. There's no italic, no light, no semibold — the contrast is binary, which keeps the system honest.

The scale runs 11 → 48px across six steps. Display is reserved for hero moments; everything UI lives in 14/16/25/28.

### Spacing & rhythm
The grid is built on a **comfortable** density: card padding 14, element gap 14, section gap 60. The 60px section gap is non-negotiable — it's what gives Contractbook its "room to breathe" feel and separates it visually from competitors like Ironclad or PandaDoc that pack content tighter.

Spacing tokens are odd-friendly (5, 7, 9, 11, 21, 22). Don't normalize to a strict 4px or 8px grid — Contractbook embraces the slightly-irregular numbers.

### Backgrounds
Plain solid surfaces. No textures, no noise, no patterns, no full-bleed photography. The hero on the marketing site uses **hand-drawn vector illustrations** filled with brand accent colors as decorative atmosphere — these are NOT photographic and NOT generated. If you don't have an asset, use a Beige or Sky Blue placeholder card with rounded 40px corners and label it.

### Borders
Hairline borders only. 1px Silver Mist (`#b3b3b3`) on inputs and ghost buttons. 1px Washed Black on the secondary ghost button when on a light surface. **No box-shadows on UI elements** — visual separation comes from radii + color blocking.

### Radii — strict, four values
- `4.375px` — inputs only (a deliberately weird number that gives form fields a *just slightly* softened edge without going pillowy)
- `24px` — cards
- `40px` — images and illustration containers
- `999px` — buttons, pills, tags

Do not invent new radii. Do not mix radii within the same component cluster.

### Cards
Solid color block, no shadow, no border (unless the surface is white-on-white, in which case use Beige). Internal padding sits between 24 and 48px depending on card scale. Cards are *generous* — empty space inside a card is part of the design.

### Shadows
None on UI elements. Hover states change color/border, not elevation. The only legal shadow is a soft `0 24px 60px rgba(26,26,26,0.06)` on top-of-stack modals and the sticky nav — and it's optional.

### Animation
- Hover transitions: `150ms ease-out`, color / background only.
- Press states: brief `100ms` scale to `0.98`, or no scale (color shift is enough).
- Page-level: no parallax, no fancy reveals. Quick fade-ins (`200ms`) for content loading.
- Illustration: the hand-drawn marks can have subtle continuous loops (a wobble, a bounce) but this is decorative — never block interaction.

### Hover & press states
- **Primary (Energy Gold)** button hover: background darkens to `#e8a800`. Press: scale 0.98.
- **Royal Blue** button hover: background lightens slightly or gets a Black 1px ring.
- **Ghost button** hover: background fills with `--bg-interactive` (Beige).
- **Links**: underline on hover; color shifts to Royal Blue if the resting state is Washed Black.

### Layout
- Max width container: **1200px**, centered.
- Hero: full-width band with centered or left-aligned headline + CTA + illustration on the right.
- Sections: alternating Pure White and Pearl bands separated by 60px.
- Two-column text-left/visual-right is the default content pattern. Card grids for features (3-up) and testimonials (3 or 4-up).
- Sticky top nav with brand mark at left, primary nav center/left, "Log in" + "Book a demo" right.

### Transparency & blur
Rare. The sticky nav can use a subtle `backdrop-filter: blur(12px)` with `rgba(255,255,255,0.85)` when content scrolls beneath it. Otherwise: solid surfaces only.

### Imagery vibe
Warm-cool neutral. Sky Blue and Thistle Bloom illustrations against white. No photography of office workers shaking hands. No stock smiles. Where real people appear (testimonial cards), keep portraits compact, square or circular, with a Beige or Pearl background — never floating on white.

---

## Iconography

Contractbook's public site leans heavily on **hand-drawn vector illustrations** for decorative moments rather than traditional small UI icons. In the marketing context, icons are barely visible — illustrations do the heavy lifting.

In the app, small UI icons are needed (sidebar, toolbars, status, etc). Since no production icon set was supplied, this design system substitutes **Lucide** as the in-app icon system.

### Why Lucide
- Stroke-based, 1.5–2px weight — matches Contractbook's clean, slightly soft geometric vocabulary.
- Open-source, comprehensive coverage of UI actions.
- Easy to recolor; pairs naturally with Washed Black on light surfaces.

### ⚠ Flagged to user
Lucide is a **substitute**. If Contractbook has a proprietary icon font or sprite, please attach it and we will swap. Stripe-style filled icons or Material-style two-tone would not match the brand and should not be used.

### Usage rules
- **Stroke weight:** 1.75px (Lucide default).
- **Size:** 16px in dense UI; 20px standard; 24px in feature cards.
- **Color:** Washed Black (`#1a1a1a`) on light backgrounds; Pure White on Royal Blue / Washed Black; **never** colored. The accent palette is for surfaces and CTAs, not icons.
- **Pairing:** Icons sit to the left of label text with `gap: 8px`.
- **No emoji.** No unicode glyphs as icons (no ✓, no →). Use Lucide's `Check`, `ArrowRight`, etc.

### CDN

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<i data-lucide="check"></i>
<script>lucide.createIcons();</script>
```

Or as inline SVG (copy from https://lucide.dev) for slides and decks.

### Logo / brand mark

A simple wordmark recreation lives at `assets/contractbook-logo.svg`. This is a **placeholder recreation** — replace with the official Contractbook logo asset when available.

---

## Quick start

```html
<link rel="stylesheet" href="colors_and_type.css">

<button style="
  background: var(--accent-primary);
  color: var(--fg-on-gold);
  border: 0;
  border-radius: var(--radius-buttons);
  padding: 16px 28px;
  font: 700 16px var(--font-abcwhyte);
  cursor: pointer;
">Book a demo</button>
```

---

## Caveats

1. **ABC Whyte is licensed** — Inter is the live substitute. Drop licensed `.woff2`s into `fonts/` to upgrade.
2. **No production source** — `ui_kits/` is built from the public marketing site + style reference, not the real codebase. Pixel-fidelity may drift from production.
3. **Lucide is a substitute icon set.** Swap when the real set is available.
4. **No real logo asset** — the wordmark in `assets/contractbook-logo.svg` is a typographic placeholder.
