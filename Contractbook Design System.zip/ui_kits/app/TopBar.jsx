// TopBar.jsx — search, notifications, new contract button
function TopBar({ onNew }) {
  return (
    <header className="topbar">
      <div className="search-wrap">
        <Icon.Search />
        <input className="search" placeholder="Search contracts, templates, people…" />
      </div>
      <div style={{ flex: 1 }} />
      <button className="icon-btn" aria-label="Notifications">
        <Icon.Bell />
      </button>
      <button className="btn btn-primary" onClick={onNew}>
        <Icon.Plus /> New contract
      </button>
      <div className="avatar">MK</div>
    </header>
  );
}
window.TopBar = TopBar;
