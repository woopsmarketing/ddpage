// ContractDetail.jsx — slide-in detail drawer
function ContractDetail({ contract, open, onClose }) {
  return (
    <React.Fragment>
      <div className={`drawer-shade ${open ? 'open' : ''}`} onClick={onClose}/>
      <aside className={`drawer ${open ? 'open' : ''}`} aria-hidden={!open}>
        <div className="drawer-head">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10, background: '#f0f0ec',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Icon.File/>
            </div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 11, color: '#6d6868', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                {contract?.type || 'Contract'}
              </div>
              <div style={{ fontWeight: 700, fontSize: 16, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 360 }}>
                {contract?.name || ''}
              </div>
            </div>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <Icon.Close/>
          </button>
        </div>

        <div className="drawer-body">
          {contract && (
            <React.Fragment>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <StatusPill status={contract.status}/>
                <span style={{ fontSize: 12, color: '#6d6868' }}>Last updated {contract.date}</span>
              </div>

              {/* Key facts card */}
              <div style={{ background: '#f7f7f3', borderRadius: 24, padding: 22, display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="kv"><span className="k">Counterparty</span><span className="v">{contract.party}</span></div>
                <div className="kv"><span className="k">Owner</span><span className="v">{contract.owner}</span></div>
                <div className="kv"><span className="k">Value</span><span className="v">{contract.value}</span></div>
                <div className="kv"><span className="k">Effective</span><span className="v">Apr 01, 2026</span></div>
                <div className="kv"><span className="k">Renewal</span><span className="v">Mar 31, 2027</span></div>
              </div>

              {/* AI extracted */}
              <div style={{ background: '#1009f6', color: '#fff', borderRadius: 24, padding: 22 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <Icon.Sparkles/>
                  <span style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#ffba09' }}>
                    Extracted by AI
                  </span>
                </div>
                <ul style={{ margin: 0, paddingLeft: 18, fontSize: 14, lineHeight: 1.55, color: 'rgba(255,255,255,0.95)' }}>
                  <li>Auto-renews unless cancelled 60 days before term end.</li>
                  <li>Net 30 payment terms · USD invoicing.</li>
                  <li>Governing law: Delaware, USA.</li>
                  <li>Mutual NDA clause included (§12).</li>
                </ul>
              </div>

              {/* Signing party */}
              <div>
                <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#6d6868', marginBottom: 10 }}>
                  Parties · 1 of 2 signed
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    background: '#f0f0ec', padding: '12px 14px', borderRadius: 14,
                  }}>
                    <div className="avatar" style={{ background: '#ffba09' }}>MK</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>Mads Kjellerup</div>
                      <div style={{ fontSize: 12, color: '#6d6868' }}>Acme Co. · CEO</div>
                    </div>
                    <span className="pill pill-signed"><Icon.Check/> Signed</span>
                  </div>
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    background: '#f0f0ec', padding: '12px 14px', borderRadius: 14,
                  }}>
                    <div className="avatar" style={{ background: '#e3c7de' }}>JL</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>Jamie Loomhill</div>
                      <div style={{ fontSize: 12, color: '#6d6868' }}>Loomhill Inc. · COO</div>
                    </div>
                    <span className="pill pill-pending">Awaiting</span>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                <button className="btn btn-primary" style={{ flex: 1 }}>
                  <Icon.Send/> Send reminder
                </button>
                <button className="btn" style={{
                  flex: 1, background: 'transparent', color: '#1a1a1a',
                  border: '1px solid #1a1a1a', borderRadius: 999, padding: '10px 18px', fontSize: 14,
                }}>
                  Open editor →
                </button>
              </div>
            </React.Fragment>
          )}
        </div>
      </aside>
    </React.Fragment>
  );
}
window.ContractDetail = ContractDetail;
