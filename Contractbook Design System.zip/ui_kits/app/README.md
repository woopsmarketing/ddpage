# App UI Kit — Contractbook

In-product recreation: sidebar nav, contracts list with status pills, top bar with search, and a detail drawer.

## Source
Built from the brand style reference (no production source provided). The information architecture is informed by the public marketing site's feature descriptions — Templates, Reminders, Integrations, Audit log, etc.

## Files

- `index.html` — interactive demo (click a row to open the detail drawer)
- `Sidebar.jsx` — left rail with logo, sections, workspace switcher
- `TopBar.jsx` — search, filters, New contract CTA, user avatar
- `ContractList.jsx` — table of contracts with status pills + AI summary column
- `ContractDetail.jsx` — slide-in detail panel with parties, dates, e-sign status
- `StatusPill.jsx` — shared status pill component (draft / pending / signed / expiring)

## Interactions you can try
- Click a contract row → detail drawer slides in
- Click the **New contract** button → toast "Draft created"
- Toggle filter chips at the top
- Click a sidebar item to change the active section

## ⚠ Caveats
- The app is a **cosmetic recreation**, not a working product.
- No real Contractbook product screenshots were provided; layout decisions inherit from the marketing brand vocabulary.
