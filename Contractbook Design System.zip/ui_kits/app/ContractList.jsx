// ContractList.jsx — main table view with filter chips
const CONTRACTS = [
  { id: 'c-1', name: 'Master Services Agreement — Loomhill Inc.',     type: 'MSA',  party: 'Loomhill Inc.',     owner: 'Mads K.',   value: '$48,000 / yr', date: 'Mar 14, 2026', status: 'pending' },
  { id: 'c-2', name: 'Vendor DPA — Stadthaus GmbH',                    type: 'DPA',  party: 'Stadthaus GmbH',    owner: 'Priya R.',  value: '—',            date: 'Mar 11, 2026', status: 'review' },
  { id: 'c-3', name: 'Employment offer — Lukas Bergström',             type: 'Offer',party: 'Lukas Bergström',   owner: 'Anna T.',   value: '€72,000 base', date: 'Mar 09, 2026', status: 'signed' },
  { id: 'c-4', name: 'NDA — Nortbridge Capital',                       type: 'NDA',  party: 'Nortbridge Capital',owner: 'Mads K.',   value: '—',            date: 'Mar 04, 2026', status: 'active' },
  { id: 'c-5', name: 'Reseller Agreement — Kemper & Co.',              type: 'MSA',  party: 'Kemper & Co.',      owner: 'Søren H.',  value: '$120,000 / yr',date: 'Feb 28, 2026', status: 'expiring' },
  { id: 'c-6', name: 'Consulting SoW — Polar Group',                   type: 'SoW',  party: 'Polar Group',       owner: 'Anna T.',   value: '$18,500',      date: 'Feb 22, 2026', status: 'draft' },
  { id: 'c-7', name: 'Subscription renewal — Vanta Legal',             type: 'MSA',  party: 'Vanta Legal',       owner: 'Mads K.',   value: '$8,400 / yr',  date: 'Feb 18, 2026', status: 'signed' },
];

function ContractList({ onOpen, selectedId }) {
  const [filter, setFilter] = React.useState('all');
  const filters = [
    { k: 'all', label: 'All', count: CONTRACTS.length },
    { k: 'pending', label: 'Pending signature', count: CONTRACTS.filter(c => c.status === 'pending').length },
    { k: 'review',  label: 'In review',         count: CONTRACTS.filter(c => c.status === 'review').length },
    { k: 'signed',  label: 'Signed',            count: CONTRACTS.filter(c => c.status === 'signed').length },
    { k: 'expiring',label: 'Expiring',          count: CONTRACTS.filter(c => c.status === 'expiring').length },
    { k: 'draft',   label: 'Drafts',            count: CONTRACTS.filter(c => c.status === 'draft').length },
  ];
  const rows = filter === 'all' ? CONTRACTS : CONTRACTS.filter(c => c.status === filter);

  return (
    <div className="content">
      <div className="page-head">
        <div>
          <h1>Contracts</h1>
          <div className="sub">7 active · 1 expiring in the next 30 days</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="icon-btn" aria-label="Filter"><Icon.Filter /></button>
          <button className="icon-btn" aria-label="Download"><Icon.Download /></button>
        </div>
      </div>

      <div className="filters">
        {filters.map(f => (
          <button key={f.k}
            className={`chip ${filter === f.k ? 'active' : ''}`}
            onClick={() => setFilter(f.k)}>
            {f.label} <span style={{ opacity: 0.6, marginLeft: 4 }}>{f.count}</span>
          </button>
        ))}
      </div>

      {/* AI summary card */}
      <div style={{
        background: '#1009f6', color: '#fff', borderRadius: 24,
        padding: 24, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 18,
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: 999, background: 'rgba(255,255,255,0.16)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <Icon.Sparkles />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#ffba09', marginBottom: 4 }}>
            AI summary
          </div>
          <div style={{ fontSize: 15, lineHeight: 1.4 }}>
            <strong>1 contract</strong> needs your attention this week — Kemper &amp; Co. renews in 14 days.
            <strong> 2 drafts</strong> are awaiting your review.
          </div>
        </div>
        <button className="btn" style={{
          background: '#ffba09', color: '#000', borderRadius: 999, padding: '10px 18px', fontSize: 14,
        }}>Review now</button>
      </div>

      <div className="table-card">
        <table className="table">
          <thead>
            <tr>
              <th style={{ width: '38%' }}>Contract</th>
              <th>Owner</th>
              <th>Value</th>
              <th>Updated</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(c => (
              <tr key={c.id}
                  className={selectedId === c.id ? 'selected' : ''}
                  onClick={() => onOpen(c)}>
                <td>
                  <div className="contract-name">{c.name}</div>
                  <div className="contract-meta">{c.type} · {c.party}</div>
                </td>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span className="avatar" style={{ width: 26, height: 26, fontSize: 11 }}>
                      {c.owner.split(' ').map(p => p[0]).join('')}
                    </span>
                    {c.owner}
                  </div>
                </td>
                <td>{c.value}</td>
                <td style={{ color: '#6d6868' }}>{c.date}</td>
                <td><StatusPill status={c.status}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
window.ContractList = ContractList;
window.CONTRACTS = CONTRACTS;
