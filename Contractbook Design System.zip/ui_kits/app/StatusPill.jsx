// StatusPill.jsx — shared status pill
const STATUS_MAP = {
  draft:    { cls: 'pill-draft',    label: 'Draft' },
  pending:  { cls: 'pill-pending',  label: 'Pending signature' },
  signed:   { cls: 'pill-signed',   label: 'Signed' },
  active:   { cls: 'pill-active',   label: 'Active' },
  review:   { cls: 'pill-review',   label: 'In review' },
  expiring: { cls: 'pill-expiring', label: 'Expiring soon' },
};
function StatusPill({ status }) {
  const s = STATUS_MAP[status] || STATUS_MAP.draft;
  return (
    <span className={`pill ${s.cls}`}>
      <span className="dot" />
      {s.label}
    </span>
  );
}
window.StatusPill = StatusPill;
window.STATUS_MAP = STATUS_MAP;
