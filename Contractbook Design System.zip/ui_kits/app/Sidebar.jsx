// Sidebar.jsx — left navigation rail
function Sidebar({ active, onSelect }) {
  const main = [
    { key: 'home',       label: 'Home',          icon: <Icon.Home/>,     count: null },
    { key: 'contracts',  label: 'Contracts',     icon: <Icon.File/>,     count: 248 },
    { key: 'templates',  label: 'Templates',     icon: <Icon.Layers/>,   count: 32 },
    { key: 'reminders',  label: 'Reminders',     icon: <Icon.Clock/>,    count: 7 },
  ];
  const config = [
    { key: 'integrations', label: 'Integrations', icon: <Icon.Plug/>, count: null },
    { key: 'settings',     label: 'Settings',     icon: <Icon.Settings/>, count: null },
  ];

  return (
    <aside className="sidebar">
      <div className="workspace">
        <span className="ws-tile">A</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 700, fontSize: 14, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            Acme Co.
          </div>
          <div style={{ fontSize: 11, color: '#6d6868' }}>Workspace</div>
        </div>
        <span style={{ color: '#6d6868', transform: 'rotate(90deg)', display: 'inline-flex' }}><Icon.Chevron/></span>
      </div>

      <div className="nav-section">
        <div className="nav-label">Workspace</div>
        {main.map(i => (
          <div key={i.key}
               className={`nav-item ${active === i.key ? 'active' : ''}`}
               onClick={() => onSelect(i.key)}>
            {i.icon}
            <span>{i.label}</span>
            {i.count != null && <span className="count">{i.count}</span>}
          </div>
        ))}
      </div>

      <div className="nav-section">
        <div className="nav-label">Configure</div>
        {config.map(i => (
          <div key={i.key}
               className={`nav-item ${active === i.key ? 'active' : ''}`}
               onClick={() => onSelect(i.key)}>
            {i.icon}<span>{i.label}</span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 'auto', background: '#f0f0ec', borderRadius: 16, padding: 14 }}>
        <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#1009f6', marginBottom: 6 }}>
          Free trial · 9 days left
        </div>
        <div style={{ fontSize: 13, lineHeight: 1.4, color: '#1a1a1a', marginBottom: 10 }}>
          Unlock unlimited contracts & integrations.
        </div>
        <button className="btn btn-primary" style={{ width: '100%' }}>Upgrade</button>
      </div>
    </aside>
  );
}
window.Sidebar = Sidebar;
