# Marketing UI Kit — Contractbook

This kit recreates Contractbook's marketing-site visual vocabulary: sticky nav, statement hero, alternating Pearl/White content bands, accent cards, testimonials, footer.

## Source
Built from the public marketing site (`https://contractbook.com`) and the brand style reference. **No production code or Figma was provided** — pixel-fidelity may drift from production.

## Files

- `index.html` — demo page that wires the whole marketing experience together
- `Nav.jsx` — sticky top nav (brand · links · login · CTA)
- `Hero.jsx` — display headline, sub, dual CTAs, illustration block
- `LogoStrip.jsx` — "trusted by" logo row
- `FeatureGrid.jsx` — 3-up feature card grid (mix of accent colors)
- `Section.jsx` — generic alternating-band layout (text-left, visual-right)
- `Testimonials.jsx` — three customer quote cards on Pearl
- `CTABanner.jsx` — Energy Gold band with primary action
- `Footer.jsx` — dark footer with column links

## Run
Open `index.html` directly. All React + Babel scripts load via CDN; no build step.

## ⚠ Caveats
- ABC Whyte → Inter substitution; see `../../fonts/README.md`.
- Logo and illustrations are placeholders.
- Copy is paraphrased from the live site, not lifted verbatim.
