// LogoStrip.jsx — "Trusted by" row of pretend-logo wordmarks
function LogoStrip() {
  const logos = ['LOOMHILL', 'Nortbridge', 'Kemper&Co', 'Vanta Legal', 'Stadthaus', 'Polar Group'];
  return (
    <section style={{ padding: '32px 0', borderTop: '1px solid #f0f0ec', borderBottom: '1px solid #f0f0ec' }}>
      <div className="container">
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 28, flexWrap: 'wrap',
        }}>
          <div style={{ fontSize: 12, color: '#6d6868', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            Trusted by teams at
          </div>
          {logos.map(l => (
            <div key={l} style={{ color: '#6d6868', fontSize: 18, fontWeight: 700, letterSpacing: '-0.01em', opacity: 0.7 }}>
              {l}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.LogoStrip = LogoStrip;
