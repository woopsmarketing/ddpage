// CTABanner.jsx — Energy Gold final CTA band
function CTABanner() {
  return (
    <section style={{ padding: '60px 0' }}>
      <div className="container">
        <div style={{
          background: '#ffba09', borderRadius: 24, padding: '60px 56px',
          display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 40, alignItems: 'center',
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <h2 className="h1" style={{ color: '#000', maxWidth: 520 }}>
              Ready to swap the spreadsheet?
            </h2>
            <p style={{ margin: 0, fontSize: 18, lineHeight: 1.5, color: '#1a1a1a', maxWidth: 480 }}>
              Tell us what you need — we'll tailor a 1:1 walkthrough. No pressure, just answers that make sense.
            </p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, justifySelf: 'end' }}>
            <button className="btn" style={{
              background: '#1a1a1a', color: '#fff', borderRadius: 999, padding: '16px 28px',
            }}>Book a demo</button>
            <button className="btn" style={{
              background: 'transparent', color: '#1a1a1a', border: '1px solid #1a1a1a',
              borderRadius: 999, padding: '15px 28px',
            }}>Try free →</button>
          </div>
        </div>
      </div>
    </section>
  );
}
window.CTABanner = CTABanner;
