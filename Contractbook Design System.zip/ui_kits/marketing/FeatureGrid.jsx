// FeatureGrid.jsx — 3-up feature cards with mixed accent colors
function FeatureGrid() {
  return (
    <section className="section">
      <div className="container">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 32, maxWidth: 720, marginBottom: 48 }}>
          <div className="eyebrow">One tool, every step</div>
          <h2 className="h1">No more clunky tools — or hours wasted searching for answers.</h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          <FeatureCard
            variant="blue"
            icon={<IconPen/>}
            kicker="Draft"
            title="Templates that don't lie."
            body="Logic-based templates pre-fill from your CRM. Legally up-to-date, every time."
          />
          <FeatureCard
            variant="gold"
            icon={<IconBolt/>}
            kicker="Sign"
            title="E-signatures, built in."
            body="From agreement to execution without leaving the platform. SOC 2 certified."
          />
          <FeatureCard
            variant="beige"
            icon={<IconBell/>}
            kicker="Track"
            title="Never miss a renewal."
            body="Reminders, audit trails, milestone alerts — so nothing slips through the cracks."
          />
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ variant, icon, kicker, title, body }) {
  const colorClass = `card-${variant}`;
  const isDark = variant === 'blue';
  const muted = isDark ? 'rgba(255,255,255,0.78)' : '#6d6868';
  return (
    <article className={colorClass} style={{
      display: 'flex', flexDirection: 'column', gap: 18, minHeight: 320, padding: 32, justifyContent: 'space-between',
    }}>
      <div style={{
        width: 44, height: 44, borderRadius: 999,
        background: isDark ? 'rgba(255,255,255,0.16)' : 'rgba(0,0,0,0.06)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>{icon}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: muted }}>
          {kicker}
        </div>
        <h3 className="h3" style={{ color: 'inherit' }}>{title}</h3>
        <p style={{ margin: 0, fontSize: 14, lineHeight: 1.5, color: isDark ? 'rgba(255,255,255,0.85)' : '#1a1a1a' }}>
          {body}
        </p>
      </div>
    </article>
  );
}

function IconPen() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 1 1 3 3L7 19l-4 1 1-4z"/>
    </svg>
  );
}
function IconBolt() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  );
}
function IconBell() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
    </svg>
  );
}

window.FeatureGrid = FeatureGrid;
