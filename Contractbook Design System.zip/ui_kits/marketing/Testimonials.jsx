// Testimonials.jsx — three customer quotes on Pearl
function Testimonials() {
  const quotes = [
    {
      text: '"This saved me 15-20 hours of manual work extracting contract data from 50 legacy DPAs. A task I had kicked down the road for years."',
      name: 'Mads K.',
      role: 'Legal Operations',
      tint: '#add3e5',
    },
    {
      text: '"With reminders, we no longer miss out on any deadlines that can have a really big impact on the business."',
      name: 'Søren H.M.',
      role: 'Founder',
      tint: '#e3c7de',
    },
    {
      text: '"The AI extracts 70-80% of the important info from a vendor agreement. Normally I have no insight into it at all."',
      name: 'Priya R.',
      role: 'Head of Procurement',
      tint: '#ffba09',
    },
  ];

  return (
    <section className="section section--pearl">
      <div className="container">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 32, maxWidth: 720, marginBottom: 48 }}>
          <div className="eyebrow">What teams say</div>
          <h2 className="h1">Half the work in fixing a problem is admitting you have one.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {quotes.map((q, i) => (
            <article key={i} style={{
              background: '#ffffff', borderRadius: 40, padding: 32,
              display: 'flex', flexDirection: 'column', gap: 24, minHeight: 280, justifyContent: 'space-between',
            }}>
              <p style={{ fontSize: 18, lineHeight: 1.45, margin: 0, color: '#1a1a1a' }}>{q.text}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 999, background: q.tint, border: '1.5px solid #1a1a1a' }}/>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{q.name}</div>
                  <div style={{ fontSize: 12, color: '#6d6868' }}>{q.role}</div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Testimonials = Testimonials;
