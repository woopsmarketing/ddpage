// Footer.jsx — dark footer with column links
function Footer() {
  const cols = [
    { title: 'Product', items: ['Contract management', 'Templates', 'E-signature', 'Integrations', 'API'] },
    { title: 'Solutions', items: ['Legal', 'Sales', 'HR', 'Procurement', 'Small business'] },
    { title: 'Resources', items: ['Blog', 'Customer stories', 'Help center', 'Changelog', 'Security'] },
    { title: 'Company', items: ['About', 'Careers', 'Contact', 'Press', 'Partners'] },
  ];
  return (
    <footer style={{ background: '#1a1a1a', color: '#ffffff', padding: '72px 0 32px' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(4, 1fr)', gap: 32, marginBottom: 56 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <img src="../../assets/contractbook-logo.svg" alt="Contractbook" style={{ height: 28, filter: 'invert(1)' }} />
            <p style={{ margin: 0, fontSize: 14, lineHeight: 1.5, color: '#b3b3b3', maxWidth: 280 }}>
              Manage, track, and finalize contracts — all in one clear, actionable space.
            </p>
          </div>
          {cols.map(c => (
            <div key={c.title} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', color: '#ffba09' }}>
                {c.title}
              </div>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {c.items.map(item => (
                  <li key={item}>
                    <a href="#" style={{ color: '#ffffff', textDecoration: 'none', fontSize: 14 }}>{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.12)', paddingTop: 24,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 14,
        }}>
          <div style={{ fontSize: 12, color: '#b3b3b3' }}>© 2026 Contractbook. All rights reserved.</div>
          <div style={{ display: 'flex', gap: 22 }}>
            {['Privacy', 'Terms', 'Cookies', 'DPA'].map(l => (
              <a key={l} href="#" style={{ color: '#b3b3b3', textDecoration: 'none', fontSize: 12 }}>{l}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;
