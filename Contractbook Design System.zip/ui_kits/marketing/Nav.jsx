// Nav.jsx — sticky top nav
function Nav() {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 50,
    background: scrolled ? 'rgba(255,255,255,0.85)' : 'rgba(255,255,255,0)',
    backdropFilter: scrolled ? 'blur(12px)' : 'none',
    WebkitBackdropFilter: scrolled ? 'blur(12px)' : 'none',
    transition: 'background 200ms ease',
    borderBottom: scrolled ? '1px solid #f0f0ec' : '1px solid transparent',
  };

  const inner = {
    maxWidth: 1200, margin: '0 auto', padding: '14px 28px',
    display: 'flex', alignItems: 'center', gap: 28,
  };
  const links = ['Product', 'Solutions', 'Templates', 'Pricing', 'Resources'];

  return (
    <nav style={navStyle}>
      <div style={inner}>
        <a href="#" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
          <img src="../../assets/contractbook-logo.svg" alt="Contractbook" style={{ height: 24 }} />
        </a>
        <ul style={{ display: 'flex', gap: 22, listStyle: 'none', margin: 0, padding: 0, flex: 1 }}>
          {links.map(l => (
            <li key={l}>
              <a href="#" style={{
                color: '#1a1a1a', textDecoration: 'none', fontSize: 14, fontWeight: 400,
              }}>{l}</a>
            </li>
          ))}
        </ul>
        <a href="#" style={{ color: '#1a1a1a', fontSize: 14, fontWeight: 400, textDecoration: 'none' }}>Log in</a>
        <button className="btn btn-primary" style={{ padding: '12px 22px', fontSize: 14 }}>Book a demo</button>
      </div>
    </nav>
  );
}

window.Nav = Nav;
