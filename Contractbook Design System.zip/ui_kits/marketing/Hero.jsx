// Hero.jsx — display headline + dual CTA + illustration
function Hero() {
  return (
    <section style={{ padding: '60px 0 80px' }}>
      <div className="container" style={{
        display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 56, alignItems: 'center',
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <div className="eyebrow">Contract management software</div>
          <h1 className="display">
            Sign in seconds,<br/>not weeks.
          </h1>
          <p className="lead" style={{ maxWidth: 480 }}>
            Everything you need to manage, track, and finalize contracts — all in one clear, actionable space.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
            <button className="btn btn-primary">Book a demo</button>
            <button className="btn btn-ghost-dark">See it in action</button>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 16, color: '#6d6868', fontSize: 12 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            SOC 2 certified
            <span style={{ width: 2, height: 2, borderRadius: 999, background: '#b3b3b3' }}/>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            Free trial, no card
          </div>
        </div>

        {/* Illustration block — hand-drawn vector placeholder */}
        <div className="illus" style={{ background: '#add3e5', minHeight: 440, padding: 36 }}>
          <HeroIllustration />
        </div>
      </div>
    </section>
  );
}

function HeroIllustration() {
  return (
    <svg viewBox="0 0 400 380" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* paper stack */}
      <rect x="78" y="62" width="220" height="280" rx="10" fill="#fff" stroke="#1a1a1a" strokeWidth="3" transform="rotate(-4 188 202)"/>
      <rect x="90" y="50" width="220" height="280" rx="10" fill="#fff" stroke="#1a1a1a" strokeWidth="3"/>
      <path d="M118 96 L282 96 M118 116 L282 116 M118 136 L260 136 M118 156 L240 156 M118 196 L282 196 M118 216 L282 216 M118 236 L230 236" stroke="#1a1a1a" strokeWidth="3" strokeLinecap="round"/>
      {/* signature line + check */}
      <path d="M118 280 Q160 268 200 280 T282 282" stroke="#1009f6" strokeWidth="4" strokeLinecap="round" fill="none"/>
      {/* gold check badge */}
      <circle cx="310" cy="290" r="34" fill="#ffba09" stroke="#1a1a1a" strokeWidth="3"/>
      <path d="M295 290 L307 302 L327 280" stroke="#1a1a1a" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
      {/* decorative dots */}
      <circle cx="50" cy="60" r="6" fill="#e3c7de" stroke="#1a1a1a" strokeWidth="2"/>
      <circle cx="358" cy="80" r="5" fill="#304801" stroke="#1a1a1a" strokeWidth="2"/>
      <path d="M30 200 L46 200 M38 192 L38 208" stroke="#1a1a1a" strokeWidth="3" strokeLinecap="round"/>
    </svg>
  );
}

window.Hero = Hero;
