// Section.jsx — two-column text + illustration section, reusable
function Section({ eyebrow, title, body, ctaLabel, variant = 'white', reverse = false, illusBg = '#e3c7de', children }) {
  const bg = variant === 'pearl' ? '#f7f7f3' : '#ffffff';
  return (
    <section style={{ background: bg, padding: '60px 0' }}>
      <div className="container">
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center',
          direction: reverse ? 'rtl' : 'ltr',
        }}>
          <div style={{ direction: 'ltr', display: 'flex', flexDirection: 'column', gap: 22 }}>
            <div className="eyebrow">{eyebrow}</div>
            <h2 className="h1">{title}</h2>
            <p className="lead" style={{ maxWidth: 460 }}>{body}</p>
            {ctaLabel && (
              <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
                <button className="btn btn-ghost-dark">{ctaLabel} →</button>
              </div>
            )}
          </div>
          <div className="illus" style={{ direction: 'ltr', background: illusBg, minHeight: 380, padding: 28 }}>
            {children}
          </div>
        </div>
      </div>
    </section>
  );
}

function IllustrationCRM() {
  return (
    <svg viewBox="0 0 380 320" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="40" y="60" width="140" height="180" rx="12" fill="#ffffff" stroke="#1a1a1a" strokeWidth="3"/>
      <rect x="58" y="84" width="104" height="14" rx="3" fill="#1009f6"/>
      <rect x="58" y="108" width="80" height="10" rx="3" fill="#1a1a1a" opacity="0.15"/>
      <rect x="58" y="126" width="90" height="10" rx="3" fill="#1a1a1a" opacity="0.15"/>
      <rect x="58" y="160" width="104" height="60" rx="6" fill="#f0f0ec"/>

      <rect x="200" y="60" width="140" height="180" rx="12" fill="#1009f6"/>
      <rect x="218" y="84" width="104" height="14" rx="3" fill="#ffba09"/>
      <rect x="218" y="108" width="80" height="10" rx="3" fill="#ffffff" opacity="0.5"/>
      <rect x="218" y="126" width="90" height="10" rx="3" fill="#ffffff" opacity="0.5"/>
      <rect x="218" y="160" width="104" height="60" rx="6" fill="rgba(255,255,255,0.18)"/>

      {/* connecting arrow */}
      <path d="M180 150 Q190 130 200 150" stroke="#1a1a1a" strokeWidth="3" fill="none" markerEnd="url(#a)"/>
      <defs>
        <marker id="a" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0 0 L10 5 L0 10 Z" fill="#1a1a1a"/>
        </marker>
      </defs>
      <circle cx="350" cy="40" r="6" fill="#ffba09" stroke="#1a1a1a" strokeWidth="2"/>
    </svg>
  );
}

function IllustrationTimeline() {
  return (
    <svg viewBox="0 0 380 320" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* big calendar */}
      <rect x="60" y="50" width="260" height="220" rx="14" fill="#ffffff" stroke="#1a1a1a" strokeWidth="3"/>
      <rect x="60" y="50" width="260" height="42" rx="14" fill="#1a1a1a"/>
      <rect x="60" y="78" width="260" height="14" fill="#1a1a1a"/>
      {/* grid */}
      {Array.from({ length: 4 }).map((_, r) =>
        Array.from({ length: 5 }).map((_, c) => (
          <rect key={`${r}-${c}`} x={76 + c * 46} y={108 + r * 38} width="38" height="30" rx="6" fill="#f7f7f3"/>
        ))
      )}
      {/* highlights */}
      <rect x="76" y="108" width="38" height="30" rx="6" fill="#ffba09"/>
      <rect x="214" y="184" width="38" height="30" rx="6" fill="#1009f6"/>
      <circle cx="260" cy="48" r="8" fill="#ffba09"/>
      <circle cx="290" cy="38" r="4" fill="#e3c7de"/>
    </svg>
  );
}

window.Section = Section;
window.IllustrationCRM = IllustrationCRM;
window.IllustrationTimeline = IllustrationTimeline;
